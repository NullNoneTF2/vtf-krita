# VTF Krita Plugin -- Full Source

Everything needed to rebuild this project from scratch.

```
BUILD.md                  <- start here: how to compile libVTFLib13.dll/.so
PATCHES.md                <- what was changed vs upstream VTFLib, and why
patches.diff               <- the actual diff, generated against a fresh
                              clone of github.com/panzi/VTFLib
VTFLib/                    <- patched VTFLib source (the library itself)
libtxc_dxtn/                <- portable DXT/S3TC compressor VTFLib links against
licenses/                   <- LGPL (VTFLib), GPL (unused parts of upstream repo,
                              kept for completeness), MIT-style (libtxc_dxtn)
krita-plugin-source/        <- the Krita plugin's own Python source
                              (ctypes bindings, export dialog, Extension)
```

## Quick start

1. Read `BUILD.md` and compile `libVTFLib13.dll` (Windows) and/or
   `libVTFLib13.so` (Linux).
2. Drop the compiled binary into `krita-plugin-source`'s expected location
   (`bin/windows/libVTFLib13.dll` or `bin/linux/libVTFLib13.so` -- you'll
   need to create the `bin/<platform>/` folders, they're not included here
   since they only ever hold a compiled binary).
3. Copy `krita-plugin-source/` (renamed to `krita_vtf/`) plus
   `krita_vtf.desktop` into your Krita `pykrita` folder, same as the
   original install instructions.

If you just want to use the plugin without rebuilding anything, you don't
need this package at all -- the original `krita_vtf_plugin.zip` already
has working prebuilt binaries for both platforms.
